import React from 'react'

import Desktop1 from './Desktop1'

const Home = () => {
  return (
    <div>
      <Desktop1/>
    </div>
  )
}

export default Home